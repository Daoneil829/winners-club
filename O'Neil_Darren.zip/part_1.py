import pandas
import pandas as pd
file_path = "C:\\Users\\13473\\Downloads\\ds_salaries.csv"
data = pd.read_csv(file_path)
## Using the file for data information
print(data.head())
print(data.shape)
print(data.job_title)
print(data['salary_in_usd'])
print(data.floc[3:11, :])
print(data.salary_in_usd.describe())
