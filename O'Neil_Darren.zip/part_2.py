import pandas as pd
file_path = "C:\\Users\\13473\\Downloads\\ds_salaries.csv"
data = pd.read_csv(file_path)
import matplotlib.pyplot as plt
plt.boxplot(data.salary_in_usd)
plt.show()
x = data.job_title
y = data.salary_in_usd
plt.bar(x, y, color='red')
plt.xlabel('Job')
plt.ylabel('salary')
plt.show()
## Finding the x's and y's in the data and setting them
plt.hist(y, bins=30)
plt.xlabel('salary')
plt.ylabel('Frequency')
plt.show()
